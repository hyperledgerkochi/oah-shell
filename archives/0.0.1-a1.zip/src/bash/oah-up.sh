#!/bin/bash

function __oah_up {
		vagrant up
}
